const express=require("express");
const path=require("path");
const Database=require("better-sqlite3");
const app=express();
const crypto=require("crypto");
const ADMIN_USER=process.env.ADMIN_USER||"admin";
const ADMIN_PASSWORD=process.env.ADMIN_PASSWORD;
if(!ADMIN_PASSWORD){console.error("Set ADMIN_PASSWORD before running publicly.");process.exit(1);}
const sessions=new Map();
function auth(req,res,next){
 const token=req.headers.authorization?.replace("Bearer ","");
 if(token && sessions.has(token)){req.admin=true;return next();}
 return res.status(401).json({error:"Unauthorized"});
}
const db=new Database("newshop.db");
db.exec(`CREATE TABLE IF NOT EXISTS orders(
 id TEXT PRIMARY KEY, created_at TEXT NOT NULL, name TEXT NOT NULL, phone TEXT NOT NULL,
 address TEXT NOT NULL, pincode TEXT NOT NULL, payment TEXT NOT NULL, total REAL NOT NULL,
 status TEXT NOT NULL, items TEXT NOT NULL
)`);
app.use(express.json({limit:"100kb"}));
app.use(express.static(path.join(__dirname,"public")));
app.post("/api/admin/login",(req,res)=>{
 const {username,password}=req.body;
 if(username!==ADMIN_USER || password!==ADMIN_PASSWORD) return res.status(401).json({error:"Invalid login"});
 const token=crypto.randomBytes(32).toString("hex"); sessions.set(token,Date.now());
 res.json({ok:true,token});
});

app.post("/api/orders",(req,res)=>{
 const {name,phone,address,pincode,payment,total,items}=req.body;
 if(!name||!phone||!address||!pincode||!payment||!total||!items?.length) return res.status(400).json({error:"Missing order details"});
 const id="NS"+Date.now().toString().slice(-9);
 db.prepare(`INSERT INTO orders VALUES(?,?,?,?,?,?,?,?,?,?)`)
 .run(id,new Date().toISOString(),name,phone,address,pincode,payment,total,"Order Received",JSON.stringify(items));
 res.json({ok:true,id});
});
app.get("/api/orders",auth,(req,res)=>{
 res.json(db.prepare("SELECT * FROM orders ORDER BY created_at DESC").all().map(o=>({...o,items:JSON.parse(o.items)})));
});
app.patch("/api/orders/:id",auth,(req,res)=>{
 const allowed=["Order Received","Paid","Processing","Shipped","Delivered","Cancelled"];
 if(!allowed.includes(req.body.status)) return res.status(400).json({error:"Invalid status"});
 const r=db.prepare("UPDATE orders SET status=? WHERE id=?").run(req.body.status,req.params.id);
 res.json({ok:r.changes>0});
});
app.get("*",(req,res)=>res.sendFile(path.join(__dirname,"public","index.html")));
app.listen(process.env.PORT||3000,()=>console.log("NEW SHOP running"));
