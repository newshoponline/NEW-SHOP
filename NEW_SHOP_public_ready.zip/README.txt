NEW SHOP FULL WEBSITE

This version includes:
- Website checkout
- Server-side order database (SQLite)
- Admin order dashboard at /admin.html
- Order status updates
- Customer name/phone/address/PIN
- UPI/COD payment choice
- No WhatsApp order sending

RUN:
1. Install Node.js 18+.
2. In this folder run: npm install
3. Run: npm start
4. Customer site: http://localhost:3000
5. Admin: http://localhost:3000/admin.html

IMPORTANT:
- The UPI ID from the earlier version is not used to automatically verify payments here. A real payment gateway/webhook is needed for automatic payment confirmation.
- Before making the shop public, add proper admin authentication and HTTPS.
- All-India shipping needs a courier/shipping provider account and integration.
