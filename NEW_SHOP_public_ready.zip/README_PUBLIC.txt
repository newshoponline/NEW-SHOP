PUBLIC-READY NEW SHOP

This package adds:
- Admin login protection
- Server-side SQLite order database
- Customer checkout
- Admin order/status dashboard
- No WhatsApp checkout

BEFORE DEPLOYING:
1. Use Node.js 18+.
2. npm install
3. Set environment variables:
   ADMIN_USER=choose-a-username
   ADMIN_PASSWORD=use-a-long-random-password
4. npm start
5. Admin: /admin.html
6. Customer: /

PAYMENT:
The website records the customer's selected payment method. It does not verify UPI payment automatically. Check your bank/UPI app yourself before marking an order Paid or dispatching it.

SHIPPING:
Customer address/PIN are collected. A real courier API/account is not included.

SECURITY:
- Use HTTPS hosting.
- Never publish the database file.
- Never put UPI PIN, OTP, CVV, card PIN or passwords in the website.
- Change the admin credentials before going live.
- Keep the Node.js dependencies updated.
